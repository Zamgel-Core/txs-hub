// 📍 Ruta del archivo: src/pages/admin/AdminDashboard.tsx

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BadgeDollarSign,
  CalendarClock,
  CheckCircle2,
  Clock3,
  GraduationCap,
  Loader2,
  ReceiptText,
  TrendingUp,
  Users,
  Wallet,
  XCircle,
} from "lucide-react";

import { Card, CardContent } from "@/src/components/ui/Card";
import {
  DashboardPayment,
  DashboardStudent,
  getDashboardData,
} from "@/src/services/dashboardService";

function formatDate(date: string | null) {
  if (!date) return "Sin fecha";

  return new Date(date).toLocaleDateString("es-MX", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
  }).format(amount);
}

function getDaysRemaining(date: string | null) {
  if (!date) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const endDate = new Date(date);
  endDate.setHours(0, 0, 0, 0);

  const diffTime = endDate.getTime() - today.getTime();

  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function isSameMonth(date: string) {
  const currentDate = new Date();
  const targetDate = new Date(date);

  return (
    currentDate.getMonth() === targetDate.getMonth() &&
    currentDate.getFullYear() === targetDate.getFullYear()
  );
}

function isToday(date: string) {
  const currentDate = new Date().toISOString().slice(0, 10);
  return date === currentDate;
}

export function AdminDashboard() {
  const [students, setStudents] = useState<DashboardStudent[]>([]);
  const [payments, setPayments] = useState<DashboardPayment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      setLoading(true);

      const data = await getDashboardData();

      setStudents(data.students);
      setPayments(data.payments);
    } catch (error) {
      console.error("Error cargando dashboard:", error);
      alert("No se pudo cargar el dashboard.");
    } finally {
      setLoading(false);
    }
  }

  const studentMap = useMemo(() => {
    return new Map(students.map((student) => [student.id, student]));
  }, [students]);

  const totalStudents = students.length;

  const activeStudents = students.filter((student) => student.is_active).length;

  const activeMemberships = students.filter(
    (student) => student.membership_status === "activa",
  ).length;

  const expiredMemberships = students.filter(
    (student) => student.membership_status === "vencida",
  ).length;

  const pendingMemberships = students.filter(
    (student) => student.membership_status === "pendiente",
  ).length;

  const beginners = students.filter(
    (student) => student.group_level === "principiante",
  ).length;

  const advanced = students.filter(
    (student) => student.group_level === "avanzado",
  ).length;

  const incomeToday = payments
    .filter((payment) => isToday(payment.payment_date))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);

  const incomeMonth = payments
    .filter((payment) => isSameMonth(payment.payment_date))
    .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);

  const upcomingExpirations = useMemo(() => {
    return students
      .filter((student) => {
        const days = getDaysRemaining(student.membership_end_date);
        return days !== null && days >= 0 && days <= 7;
      })
      .sort((a, b) => {
        return (
          new Date(a.membership_end_date || "").getTime() -
          new Date(b.membership_end_date || "").getTime()
        );
      })
      .slice(0, 6);
  }, [students]);

  const membershipBreakdown = {
    semanal: students.filter((student) => student.membership_type === "semanal")
      .length,
    quincenal: students.filter(
      (student) => student.membership_type === "quincenal",
    ).length,
    mensual: students.filter((student) => student.membership_type === "mensual")
      .length,
  };

  const recentPayments = payments.slice(0, 8);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="text-center">
          <Loader2 className="mx-auto mb-5 h-12 w-12 animate-spin text-yellow-400" />
          <p className="text-sm uppercase tracking-widest text-zinc-500">
            Cargando dashboard real...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-white md:text-5xl">
            Dashboard Administrativo
          </h1>

          <p className="mt-3 max-w-2xl text-zinc-400">
            Métricas reales de alumnos, pagos, membresías y vencimientos de TXS.
          </p>
        </div>

        <div className="flex items-center gap-3 rounded-2xl border border-yellow-500/20 bg-yellow-500/10 px-5 py-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-yellow-500/20 bg-yellow-500/10">
            <TrendingUp className="h-5 w-5 text-yellow-400" />
          </div>

          <div>
            <p className="text-xs uppercase tracking-widest text-zinc-500">
              Sistema activo
            </p>
            <p className="font-semibold text-white">
              {activeStudents} alumnos habilitados
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="border-yellow-500/10">
          <CardContent className="p-6">
            <Users className="mb-5 h-8 w-8 text-yellow-400" />
            <p className="text-sm text-zinc-500">Total alumnos</p>
            <h2 className="mt-2 text-5xl font-bold text-white">
              {totalStudents}
            </h2>
          </CardContent>
        </Card>

        <Card className="border-emerald-500/10">
          <CardContent className="p-6">
            <CheckCircle2 className="mb-5 h-8 w-8 text-emerald-400" />
            <p className="text-sm text-zinc-500">Membresías activas</p>
            <h2 className="mt-2 text-5xl font-bold text-white">
              {activeMemberships}
            </h2>
          </CardContent>
        </Card>

        <Card className="border-red-500/10">
          <CardContent className="p-6">
            <XCircle className="mb-5 h-8 w-8 text-red-400" />
            <p className="text-sm text-zinc-500">Membresías vencidas</p>
            <h2 className="mt-2 text-5xl font-bold text-white">
              {expiredMemberships}
            </h2>
          </CardContent>
        </Card>

        <Card className="border-amber-500/10">
          <CardContent className="p-6">
            <Clock3 className="mb-5 h-8 w-8 text-amber-400" />
            <p className="text-sm text-zinc-500">Pendientes</p>
            <h2 className="mt-2 text-5xl font-bold text-white">
              {pendingMemberships}
            </h2>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <Card className="border-emerald-500/10">
          <CardContent className="p-6">
            <Wallet className="mb-5 h-8 w-8 text-emerald-400" />
            <p className="text-sm text-zinc-500">Ingresos de hoy</p>
            <h2 className="mt-2 text-4xl font-bold text-white">
              {formatCurrency(incomeToday)}
            </h2>
          </CardContent>
        </Card>

        <Card className="border-yellow-500/10">
          <CardContent className="p-6">
            <BadgeDollarSign className="mb-5 h-8 w-8 text-yellow-400" />
            <p className="text-sm text-zinc-500">Ingresos del mes</p>
            <h2 className="mt-2 text-4xl font-bold text-white">
              {formatCurrency(incomeMonth)}
            </h2>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardContent className="p-6">
            <div className="mb-8 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Próximos vencimientos
                </h2>
                <p className="mt-1 text-sm text-zinc-500">
                  Membresías que vencen en los próximos 7 días.
                </p>
              </div>

              <CalendarClock className="h-7 w-7 text-red-400" />
            </div>

            {upcomingExpirations.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-zinc-800 p-8 text-center">
                <p className="text-zinc-500">No hay vencimientos próximos.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingExpirations.map((student) => {
                  const remaining = getDaysRemaining(
                    student.membership_end_date,
                  );

                  return (
                    <div
                      key={student.id}
                      className="flex flex-col gap-4 rounded-2xl border border-zinc-800 bg-zinc-900/40 p-5 md:flex-row md:items-center md:justify-between"
                    >
                      <div>
                        <h3 className="text-lg font-semibold text-white">
                          {student.full_name}
                        </h3>
                        <p className="mt-1 text-sm text-zinc-500">
                          {student.group_level} •{" "}
                          {student.membership_type || "Sin membresía"}
                        </p>
                      </div>

                      <div className="text-left md:text-right">
                        <p className="text-sm text-zinc-400">
                          Vence: {formatDate(student.membership_end_date)}
                        </p>
                        <p className="mt-2 text-sm font-semibold text-amber-400">
                          {remaining === 0
                            ? "Vence hoy"
                            : `${remaining} día(s) restantes`}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-white">Distribución</h2>
            <p className="mt-1 text-sm text-zinc-500">Tipos de membresía.</p>

            <div className="mt-8 space-y-5">
              {Object.entries(membershipBreakdown).map(([type, count]) => (
                <div key={type}>
                  <div className="mb-2 flex items-center justify-between">
                    <p className="capitalize text-zinc-300">{type}</p>
                    <p className="font-semibold text-white">{count}</p>
                  </div>

                  <div className="h-2 overflow-hidden rounded-full bg-zinc-800">
                    <div
                      className="h-full rounded-full bg-yellow-500"
                      style={{
                        width: `${totalStudents ? (count / totalStudents) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 grid grid-cols-2 gap-4 border-t border-zinc-800 pt-6">
              <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-4">
                <GraduationCap className="mb-3 h-5 w-5 text-yellow-400" />
                <p className="text-sm text-zinc-400">Principiantes</p>
                <h3 className="mt-2 text-3xl font-bold text-white">
                  {beginners}
                </h3>
              </div>

              <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-4">
                <ReceiptText className="mb-3 h-5 w-5 text-yellow-400" />
                <p className="text-sm text-zinc-400">Avanzados</p>
                <h3 className="mt-2 text-3xl font-bold text-white">
                  {advanced}
                </h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">Pagos recientes</h2>
              <p className="mt-1 text-sm text-zinc-500">
                Últimos movimientos registrados en historial real.
              </p>
            </div>

            <Wallet className="h-7 w-7 text-emerald-400" />
          </div>

          {recentPayments.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-zinc-800 p-8 text-center">
              <p className="text-zinc-500">
                No existen pagos registrados todavía.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentPayments.map((payment) => {
                const student = studentMap.get(payment.student_id);

                return (
                  <div
                    key={payment.id}
                    className="flex flex-col gap-4 rounded-2xl border border-zinc-800 bg-zinc-900/40 p-5 lg:flex-row lg:items-center lg:justify-between"
                  >
                    <div>
                      <h3 className="text-lg font-semibold text-white">
                        {student?.full_name || "Alumno no encontrado"}
                      </h3>
                      <p className="mt-1 text-sm text-zinc-500">
                        {payment.concept} • {payment.method}
                      </p>
                    </div>

                    <div className="text-left lg:text-right">
                      <p className="font-semibold text-emerald-400">
                        {formatCurrency(Number(payment.amount || 0))}
                      </p>
                      <p className="mt-1 text-sm text-zinc-400">
                        {formatDate(payment.payment_date)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {expiredMemberships > 0 && (
        <Card className="border-red-500/10 bg-gradient-to-r from-red-500/5 to-transparent">
          <CardContent className="flex flex-col gap-5 p-6 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-red-500/20 bg-red-500/10">
                <AlertTriangle className="h-6 w-6 text-red-400" />
              </div>

              <div>
                <h2 className="text-xl font-bold text-white">
                  Atención administrativa
                </h2>

                <p className="mt-2 max-w-2xl text-sm leading-relaxed text-zinc-400">
                  Actualmente existen {expiredMemberships} membresías vencidas.
                  Se recomienda actualizar pagos y renovaciones.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
